import java.util.*;
public class Main {
  public static void main(String[] args){

    // Create a Hashmap mapping characters of OnePiece to a fact about them
    HashMap<Character, String> onepieceCharacters = new HashMap<>();
    onepieceCharacters.put('L', "Luffy is main character of One Piece");
    onepieceCharacters.put('Z', "Zoro is the main character of One Piece");
    onepieceCharacters.put('N', "Nami is the main character of One Piece");
    onepieceCharacters.put('U', "Usopp is the main character of One Piece");
    onepieceCharacters.put('S', "Sanji is the main character of One Piece");
    onepieceCharacters.put('T', "Tony Tony Chopper is the main character of One Piece");
    onepieceCharacters.put('R', "Robin is the main character of One Piece");
    onepieceCharacters.put('F', "Franky is the main character of One Piece");
    onepieceCharacters.put('B', "Brook is the main character of One Piece");
    onepieceCharacters.put('J', "Jinbe is the main character of One Piece");

    // Ask the user which character they want to know about
    Scanner scanner = new Scanner(System.in);
    System.out.println("Which One Piece character do you want to know about? (Enter the first letter of the character's name)");
    char character = scanner.next().charAt(0);

    // Print the fact related about the choosen character
    String fact = onepieceCharacters.get(character);
    if (fact != null){
      System.out.println(fact);
    } else {
      System.out.println("Sorry, I don't have a fact about that character.");
    }
    }}